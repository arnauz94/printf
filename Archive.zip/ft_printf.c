#include "libft/libft.h"
#include "ft_printf.h"
#include <stdio.h>

void		testread(t_args a)
{
	printf("\n\n- : %d\n", a.minus);
	printf("+ : %d\n", a.plus);
	printf("# : %d\n", a.sharp);
	printf("space : %d\n", a.space);
	printf("0 : %d\n", a.zero);
	printf("size : %d\n", a.size);
	printf("precision : %d\n", a.precision);
	printf("convert : %s\n", a.convert);
	printf("type : %c\n", a.type);
	printf("valu : %s\n", a.valu);
}

t_args		init_args(t_args args)
{

	args.minus = 0;
	args.plus = 0;
	args.sharp = 0;
	args.space = 0;
	args.zero = 0;
	args.size = 0;
	args.precision = -1;
	args.per_cent = 0;
	args.convert = "";
	args.type = 0;
	args.valu = NULL;

	return (args);
}

char		*removeparam(char *format)
{
	size_t	cpt;
	size_t	begin;
	size_t	end;
	int		len;
	int		cptret;
	char	*ret;

	cpt = ft_strlen(format) - ft_strlen(strchr(format, '%'));
	begin = cpt;
	while (cpt < ft_strlen(format) && (format[cpt] != 's' && format[cpt] != 'S' &&
		format[cpt] != 'D' && format[cpt] != 'p' && format[cpt] != 'o' &&
		format[cpt] != 'u' && format[cpt] != 'x' && format[cpt] != 'X' &&
		format[cpt] != 'd' && format[cpt] != 'i' && format[cpt] != 'c' &&
		format[cpt] != 'C'))
	{
		cpt++;
	}
	end = cpt;
	len = end - begin;
	ret = ft_strnew(ft_strlen(format - len));
	cpt = 0;
	cptret = 0;
	while (cpt < ft_strlen(format))
	{

		if (cpt < begin || cpt > end)
		{
			ret[cptret] = format[cpt];
			cptret++;
		}
		cpt++;
	}
	ret[cptret] = '\0';
	return (ret);
}

char	*toString(char *format, t_args args)
{
	char	*ret;
	char	*tmp;
	size_t	argbegin;
	size_t	cpt;
	size_t	cptvalu;
	size_t	len;

	cpt = 0;
	cptvalu = 0;
	ret = NULL;
	argbegin = ft_strlen(format) - ft_strlen(strchr(format, '%'));
	format = removeparam(format);
	printf("yooooooooooooooooooooooooo\n");
	ret = ft_strnew(ft_strlen(format) + ft_strlen(args.valu) + 1);
	printf("yooooooooooooooooooooooooo\n");
	tmp = ft_strdup(format);
	while (cpt < argbegin)
	{
		ret[cpt] = tmp[cpt];
		cpt++;
	}
	while (cptvalu < ft_strlen(args.valu))
	{
		ret[cpt] = args.valu[cptvalu];
		cpt++;
		cptvalu++;

	}
	cpt = cpt - cptvalu;
	
	len	= ft_strlen(format);
	while (cpt < len)
	{
		ret[cpt + cptvalu] = tmp[cpt];
		cpt++;
	}
	ret[cpt + cptvalu] = '\0';
	return (ret);
}

int     ft_printf(const char *format, ...)
{
	char	*arg;
	char	*ret;
	t_args	args;
	va_list ap;

	va_start(ap, format);
	arg = (char*)format;
	ret = (char*)format;
	while ((arg = ft_strchr(arg, '%')))
	{
		args = init_args(args);
		args = read_flag_and_field(&arg, args);
		args = read_precision(&arg, args);
		args = read_convert(&arg, args);
		args = read_type_and_valu(&arg, args, ap);
		args = handling_precision(args);
		args = handling_minf_plus(args);
		testread(args);
		
		ret = toString(ret, args);
		arg = ret;
	}
	printf("%s", ret);
	va_end(ap);
	return (0);
}
